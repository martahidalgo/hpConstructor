
About the number of pathways to download for each species
-------------------------------------------------------------

Four of the pathways existing for human (hsa), i.e. hsa05110, hsa05120, hsa05130 and hsa05131, do not exist for mouse (mmu) and rat (rno). Therefore, they are not downloaded.
